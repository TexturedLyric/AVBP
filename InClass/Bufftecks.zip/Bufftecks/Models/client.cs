using System;

namespace Bufftecks.Models
{
    public class Client
    {
        public string projectList{get; set;}//project list
        public int clientId{get; set;}//id
        public string firstName{get; set;}//FN
        public string lastName{get; set;}//LN
        public int phoneNumber{get; set;}//phone
        public string email{get; set;}//email
    }
}