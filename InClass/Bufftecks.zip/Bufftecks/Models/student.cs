using System;

namespace Bufftecks.Models
{
    public class student
    {
        public string stuId{get; set;}
        public string firstName{get; set;}
        public string lastName{get; set;}
        public int stuPhone{get; set;}
        public string email{get; set;}
        public string role {get; set;}
    }
}