using System;

namespace Buffteks2
{
    public class Orginization
    {
        public int orgId{get; set;}
        public string orgName{get; set;}
        public string orgPhone{get; set;}
        public string orgEmail{get; set;}
        public string orgContactList{get; set;}
    }
}