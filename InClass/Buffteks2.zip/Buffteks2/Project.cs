using System;

namespace Buffteks2
{
    public class project
    {
        public int projectId {get; set;}
        public string  projectName {get; set;}
        public string teamLead {get; set;}
        public string hoursWorked {get; set;}
        public string clientName {get; set;}
        public string deadLine {get; set;}
    }
}