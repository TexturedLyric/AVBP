using System;

namespace MVCAssignment7.Models
{
    public class ConverterViewModel
    {
        public decimal ValueToCon {get; set;}
        public string ConType {get; set;}
        public decimal ConValue {get; set;}
    }
}